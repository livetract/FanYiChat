﻿namespace QiaYue.UI.Models
{
    internal class InputTextItem
    {
        public string InputPlaceholder { get; set; } = string.Empty;
        public bool IsGotFocus { get; set; } = false;
        public string InputText { get; set; } = string.Empty;
    }
}
