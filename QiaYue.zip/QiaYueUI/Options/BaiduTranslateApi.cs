﻿namespace QiaYue.UI.Options;

public class BaiduTranslateApi
{
    public string AppId { get; set; } = string.Empty;
    public string AppKey { get; set; } = string.Empty;
    public string ApiUrl { get; set; } = string.Empty;
}