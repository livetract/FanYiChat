﻿namespace QiaYue.UI.Options
{
    public class ConfigModel
    {
        public BaiduTranslateApi BaiduTranslateApi { get; set; } = new BaiduTranslateApi();
    }
}